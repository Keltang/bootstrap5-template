﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HR.LeaveManagement.Application.Constants
{
    public static class CustomClaimTypes
    {
        public const string Uid = "uid";
    }
}
