﻿namespace HR.LeaveManagement.Application.Models.Identity
{
    public class RegistrationResponse
    {
        public string UserId { get; set; }
    }
}
