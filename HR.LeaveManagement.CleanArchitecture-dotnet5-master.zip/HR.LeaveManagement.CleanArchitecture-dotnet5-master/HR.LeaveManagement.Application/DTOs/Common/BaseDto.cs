﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HR.LeaveManagement.Application.DTOs.Common
{
    public abstract class BaseDto
    {
        public int Id { get; set; }
    }
}
